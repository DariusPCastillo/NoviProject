﻿namespace NoviProject.Models
{
    public class MemberType
    {
        public string? UniqueID { get; set; }
        public string? Name { get; set; }
        public string? Description { get; set; }
        public bool ForCompanies { get; set; }
    }
}
