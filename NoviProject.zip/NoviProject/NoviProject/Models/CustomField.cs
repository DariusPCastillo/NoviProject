﻿namespace NoviProject.Models
{
    public class CustomField
    {
        public string? CustomFieldUniqueID { get; set; }
        public string? Value { get; set; }
        public bool IsSumOfChildren { get; set; }
    }
}
