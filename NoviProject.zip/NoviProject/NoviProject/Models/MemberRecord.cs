﻿namespace NoviProject.Models
{
    public class MemberRecord
    {
        public int TotalCount { get; set; }
        public List<Member>? Results { get; set; }
    }
}
